# Cutwise: agentic video editor (frontend prototype)

A clickable prototype of the full workflow, running on realistic mock data. There is no backend yet: no Agnes, FFmpeg, speech-to-text or real ContextGuard. The mock planner is deterministic but genuinely reacts to every control, so the demo behaves like the real product.

```bash
npm install
npm run dev          # http://localhost:5173
npm run build
npx tsx scripts/plan-check.ts   # prints agent plans for the demo scenarios
```

## The demo flow

1. **Footage.** Drop any file (it uses the lecture analysis) or pick one of three samples: an SQL injection lecture (Education), a Mysore travel vlog (Travel) and a cricket final (Sports).
2. **Understand.** A mock pipeline runs, then the screen shows the detected category (which you can change), the lens it uses, the creator's intent (editable), the top-ranked moments (they re-rank when the category changes), the conditions in the raw footage (repetition, tangents, corrections, speakers, mixed languages, noise, pauses), and the context links ContextGuard will protect.
3. **Brief.** Type or "speak" (mocked) an instruction, and the audience, purpose, length, requirements and must-keep topics fill in from it. **Plan this edit** makes one version; the preset link makes three audience-specific versions from the same footage.
4. **Edit and refine.**
   - **Agent run** replays the agent's 14-step reasoning, including re-plans.
   - The **timeline** links the full source to the edited version, so you can see which pieces were kept and where they land.
   - **Edit decisions** shows KEEP / CUT / PROTECTED / CONTEXT RISK for every segment, with Why, Restore, Cut and Protect.
   - **ContextGuard** shows word-level before and after for every rejected or flagged cut.
   - **Chat** handles conversational re-editing. Each brief change creates a new version that keeps the earlier constraints and manual changes.
   - **Download edit list** exports the EDL JSON that FFmpeg will consume.

### A scripted demo (about 2 minutes)

1. Open the SQL lecture, continue, click **Use: "Make this a 3-minute revision…"**, then **Plan this edit**.
2. Open **ContextGuard**. A pause-removal cut would have turned "is NOT secure" into "is secure", so it was rejected.
3. In chat: *"Make it around one minute, but don't remove the SQL injection example."* The agent spots the conflict with "keep all examples", restores the vulnerable query the bypass depends on, and says it went 13 seconds over target to keep the meaning.
4. *"Make a 10-minute version for professionals"* brings advanced material back in and rejects a second unsafe cut ("Stored procedures are safe, *but only if*…").
5. Cut **Q: Is escaping quotes enough?** The answer turns into a CONTEXT RISK for you to review.
6. Try the cricket sample with the three-versions preset, then *"Restore the LBW call"*. ContextGuard brings back the review that overturned it.

## Architecture

```
src/
  types.ts                 Domain model: Video, Segment, Brief, EditPlan, GuardIssue, Version
  data/                    Mock analysis output (what STT + Agnes will produce)
    categories.ts          Category lenses, audience/purpose biases, controls
    sqlLecture.ts          Hero sample, 22 segments with real-world mess
    samples.ts             Travel vlog + cricket match
  engine/                  Mock "brain". Replaced by Agnes reasoning later
    planner.ts             Scoring → protection → EDL draft → ContextGuard → re-plan loop
    contextGuard.ts        Negation/qualifier cuts, dependencies, Q&A, corrections
    instructions.ts        Natural-language → Brief, segment matching for chat
  services/agent.ts        THE BACKEND SEAM: components only call this module
  lib/edit.ts              Output clip mapping, spoken text, EDL export
  state/store.tsx          useReducer store: stage, versions, chat, selection
  screens/                 Upload, Understand, Brief, Workspace
  components/workspace/    Timeline, Preview, SegmentList, SidePanel, ChatPanel, VersionBar
```

### Plugging in the backend

| Mock today | Real implementation |
|---|---|
| `data/*.ts` segments, tags, `dependsOn`, `corrects`, `repeats`, `innerCuts` | STT with timestamps + diarisation, then Agnes 3.0 Flash segmenting, tagging and linking |
| `engine/planner.ts` `planEdit()` | Agnes agent loop producing the same `EditPlan` shape |
| `engine/contextGuard.ts` | Agnes comparing original vs edited transcript windows |
| `services/agent.ts` `sendMessage()` | LLM intent routing over the active version |
| `lib/edit.ts` `toEDL()` | Input to FFmpeg, which edits the original footage deterministically |

If the backend returns the types in `types.ts`, the UI needs no changes.

## Design notes

- The four decision colours mean the same thing everywhere: teal keep, indigo protected, amber context risk, and hatched grey cut. Each also has its own glyph, so they still read in greyscale.
- What people actually said is set in a serif (Newsreader), so it stands apart from interface text (Schibsted Grotesk).
