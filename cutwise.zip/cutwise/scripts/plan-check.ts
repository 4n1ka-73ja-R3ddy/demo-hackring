// Prints the plan for the demo scenarios. Run: npx tsx scripts/plan-check.ts
import { sqlLecture } from '../src/data/sqlLecture'
import { mysoreVlog, cricketMatch } from '../src/data/samples'
import { planEdit } from '../src/engine/planner'
import { parseInstruction, applyInstruction } from '../src/engine/instructions'
import type { Brief, Video } from '../src/types'

const base = (v: Video): Brief => ({ category: v.detectedCategory, audience: 'general', purpose: 'summary', targetSeconds: 300, requirements: ['remove-repetition', 'remove-pauses'], lockedTopics: [], instruction: '' })
function run(v: Video, instr: string[]) {
  let b = base(v)
  for (const i of instr) {
    const p = parseInstruction(i, v)
    b = applyInstruction(b, p, i)
    const plan = planEdit(v, b)
    console.log(`\n=== ${v.id} :: "${i}"\n understood: ${p.understood.join(' | ')}\n out ${plan.outputSeconds}s hit=${plan.hitTarget} replans=${plan.replans}`)
    for (const s of plan.steps) console.log(`  [${s.status}] ${s.label}: ${s.detail}`)
    for (const d of plan.decisions) console.log(`   ${d.decision.padEnd(9)} ${d.segmentId} ${String(d.keptSeconds).padStart(4)}s ${d.importance.padEnd(6)} ${d.reason}`)
  }
}
run(sqlLecture, ['Make this a 3-minute revision video for beginners. Keep all security examples.', "Make it around one minute, but don't remove the SQL injection example.", 'Now a 10 minute version for professionals'])
run(mysoreVlog, ['Turn this into a 60-second reel for my followers. Keep the palace lights and the sunrise.'])
run(cricketMatch, ['Make 60-second highlights for the college Instagram. Keep the last over.'])
