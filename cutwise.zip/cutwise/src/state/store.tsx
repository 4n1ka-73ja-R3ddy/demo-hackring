import { createContext, useContext, useReducer, type ReactNode } from 'react'
import type { Brief, CategoryId, ChatMessage, Version, Video } from '../types'

export type Stage = 'upload' | 'understand' | 'brief' | 'edit'

export interface AppState {
  stage: Stage
  video: Video | null
  uploadedName: string | null
  category: CategoryId | null
  intent: string
  briefDraft: Brief | null
  versions: Version[]
  activeVersionId: string | null
  selectedSegmentId: string | null
  chat: ChatMessage[]
  /** Version whose agent run is currently animating */
  runningVersionId: string | null
  sidePanel: 'why' | 'guard' | 'agent'
}

const initial: AppState = {
  stage: 'upload',
  video: null,
  uploadedName: null,
  category: null,
  intent: '',
  briefDraft: null,
  versions: [],
  activeVersionId: null,
  selectedSegmentId: null,
  chat: [],
  runningVersionId: null,
  sidePanel: 'agent',
}

type Action =
  | { type: 'load-video'; video: Video; uploadedName?: string }
  | { type: 'go'; stage: Stage }
  | { type: 'set-category'; category: CategoryId }
  | { type: 'set-intent'; intent: string }
  | { type: 'set-brief'; brief: Brief }
  | { type: 'add-versions'; versions: Version[]; chat?: ChatMessage[] }
  | { type: 'replace-version'; version: Version }
  | { type: 'activate'; id: string }
  | { type: 'select'; id: string | null; panel?: AppState['sidePanel'] }
  | { type: 'chat'; message: ChatMessage }
  | { type: 'run-done' }
  | { type: 'panel'; panel: AppState['sidePanel'] }
  | { type: 'reset' }

function reducer(s: AppState, a: Action): AppState {
  switch (a.type) {
    case 'load-video':
      return {
        ...initial,
        stage: 'understand',
        video: a.video,
        uploadedName: a.uploadedName ?? null,
        category: a.video.detectedCategory,
        intent: a.video.intent,
      }
    case 'go':
      return { ...s, stage: a.stage }
    case 'set-category': {
      const intent = s.video?.intentByCategory?.[a.category] ?? s.video?.intent ?? ''
      return { ...s, category: a.category, intent, briefDraft: s.briefDraft ? { ...s.briefDraft, category: a.category } : null }
    }
    case 'set-intent':
      return { ...s, intent: a.intent }
    case 'set-brief':
      return { ...s, briefDraft: a.brief }
    case 'add-versions': {
      const last = a.versions[a.versions.length - 1]
      return {
        ...s,
        stage: 'edit',
        versions: [...s.versions, ...a.versions],
        activeVersionId: last.id,
        runningVersionId: last.id,
        selectedSegmentId: null,
        sidePanel: 'agent',
        chat: [...s.chat, ...(a.chat ?? [])],
      }
    }
    case 'replace-version':
      return { ...s, versions: s.versions.map((v) => (v.id === a.version.id ? a.version : v)) }
    case 'activate':
      return { ...s, activeVersionId: a.id }
    case 'select':
      return { ...s, selectedSegmentId: a.id, sidePanel: a.panel ?? (a.id ? 'why' : s.sidePanel) }
    case 'chat':
      return { ...s, chat: [...s.chat, a.message] }
    case 'run-done':
      return { ...s, runningVersionId: null }
    case 'panel':
      return { ...s, sidePanel: a.panel }
    case 'reset':
      return initial
  }
}

const Ctx = createContext<{ state: AppState; dispatch: React.Dispatch<Action> } | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial)
  return <Ctx.Provider value={{ state, dispatch }}>{children}</Ctx.Provider>
}

export function useStore() {
  const c = useContext(Ctx)
  if (!c) throw new Error('useStore outside provider')
  return c
}

export function useActiveVersion() {
  const { state } = useStore()
  return state.versions.find((v) => v.id === state.activeVersionId) ?? null
}
