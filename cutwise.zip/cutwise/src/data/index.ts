import { cricketMatch, mysoreVlog } from './samples'
import { sqlLecture } from './sqlLecture'

export const videos = [sqlLecture, mysoreVlog, cricketMatch]

/** Chat suggestions per video, used in the re-edit panel. */
export const chatSuggestions: Record<string, string[]> = {
  'sql-lecture': [
    "Make it around one minute, but don't remove the SQL injection example.",
    'Why did you cut the college fest story?',
    'Restore the ORM answer',
    'Make a 10-minute version for professionals',
  ],
  'mysore-vlog': [
    'Make it 30 seconds',
    'Why did you cut the dosa?',
    'Restore the dosa',
    'Make a 5-minute summary for a general audience. Keep the recommendations.',
  ],
  'cricket-final': [
    'Make it 30 seconds',
    'Restore the LBW call',
    'Why did you cut the collapse?',
    'Make a 5-minute summary',
  ],
}
