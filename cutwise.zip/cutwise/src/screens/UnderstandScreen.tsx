import { useEffect, useMemo, useState } from 'react'
import { CATEGORIES, categoryById } from '../data/categories'
import { FILLER_TAGS, scoreAll } from '../engine/planner'
import { tc } from '../lib/format'
import { useStore } from '../state/store'
import { Button, Card, Choice, cx } from '../components/ui'
import type { Segment, Video } from '../types'

const PIPELINE = [
  'Extract audio',
  'Transcribe with timestamps',
  'Separate speakers and languages',
  'Detect content category',
  'Run category-specific analysis',
  'Infer creator intent',
]

const analyzed = new Set<string>()

const speakerName = (v: Video, id: string) => v.speakers.find((s) => s.id === id)?.name ?? id

function kindOf(s: Segment): 'content' | 'filler' | 'dialogue' {
  if (s.tags.some((t) => FILLER_TAGS.includes(t))) return 'filler'
  if (s.tags.includes('question') || s.tags.includes('answer')) return 'dialogue'
  return 'content'
}

export function UnderstandScreen() {
  const { state, dispatch } = useStore()
  const video = state.video!
  const category = state.category!
  const [done, setDone] = useState(analyzed.has(video.id) ? PIPELINE.length : 0)
  const [changing, setChanging] = useState(false)

  useEffect(() => {
    if (done >= PIPELINE.length) { analyzed.add(video.id); return }
    const t = setTimeout(() => setDone((d) => d + 1), done === 3 ? 650 : 380)
    return () => clearTimeout(t)
  }, [done, video.id])

  const ready = done >= PIPELINE.length
  const lens = categoryById(category)
  const ranked = useMemo(() => {
    const scores = scoreAll(video, { category, audience: 'general', purpose: 'full', targetSeconds: video.duration, requirements: [], lockedTopics: [], instruction: '' })
    return [...video.segments].sort((a, b) => scores.get(b.id)! - scores.get(a.id)!).slice(0, 6).map((s) => ({ s, score: scores.get(s.id)! }))
  }, [video, category])

  const repeats = video.segments.filter((s) => s.repeats)
  const tangents = video.segments.filter((s) => s.tags.includes('tangent'))
  const corrections = video.segments.filter((s) => s.corrects)
  const mixed = video.segments.filter((s) => s.lang.length > 1 || s.lang[0] !== 'en')
  const noisy = video.segments.filter((s) => s.noise && s.noise !== 'low')
  const pauses = video.segments.filter((s) => s.tags.includes('pause'))
  const links = [
    ...video.segments.flatMap((s) => (s.dependsOn ?? []).map((d) => ({ from: video.segments.find((x) => x.id === d)!, to: s, kind: s.tags.includes('answer') ? 'Question and answer' : 'Depends on' }))),
    ...corrections.map((c) => ({ from: video.segments.find((x) => x.id === c.corrects)!, to: c, kind: 'Corrected later' })),
  ].sort((a, b) => a.from.start - b.from.start)

  return (
    <div className="mx-auto max-w-[1180px] px-4 pb-24 pt-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight">{video.title}</h1>
          <p className="tnum mt-1 text-[14px] text-muted">
            {tc(video.duration)} of footage, {video.speakers.length} speakers, {video.languages.map((l) => `${l.name} ${Math.round(l.share * 100)}%`).join(', ')}
          </p>
        </div>
        <Button variant="primary" disabled={!ready} onClick={() => dispatch({ type: 'go', stage: 'brief' })}>
          Continue to brief
        </Button>
      </div>

      {/* Source map */}
      <div className="mt-6">
        <div className="flex h-10 gap-[2px] overflow-hidden rounded-lg" role="img" aria-label="Source footage map: content, dialogue and filler">
          {video.segments.map((s, i) => {
            const k = kindOf(s)
            return (
              <div
                key={s.id}
                title={`${tc(s.start)} ${s.title}`}
                style={{ flex: s.end - s.start, transitionDelay: `${i * 25}ms` }}
                className={cx(
                  'transition-opacity duration-300',
                  done >= 2 ? 'opacity-100' : 'opacity-15',
                  k === 'content' && 'bg-ink-2',
                  k === 'dialogue' && 'bg-[#6E7FA8]',
                  k === 'filler' && 'hatch bg-cut-soft',
                )}
              />
            )
          })}
        </div>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-muted">
          <span className="flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-ink-2" />Teaching content</span>
          <span className="flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-[#6E7FA8]" />Questions and answers</span>
          <span className="flex items-center gap-1.5"><i className="hatch size-2.5 rounded-sm bg-cut-soft" />Repetition, tangents, noise, pauses</span>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[300px_1fr]">
        <Card className="h-fit p-5">
          <h2 className="text-[15px] font-semibold">Analysis</h2>
          <ol className="mt-3 space-y-2.5">
            {PIPELINE.map((p, i) => (
              <li key={p} className="flex items-center gap-3 text-[14px]">
                <span
                  className={cx(
                    'grid size-5 shrink-0 place-items-center rounded-full text-[11px]',
                    i < done ? 'bg-keep text-white' : i === done ? 'border-2 border-ink' : 'border border-line',
                  )}
                  aria-hidden
                >
                  {i < done ? '✓' : i === done ? <i className="pulse-dot size-1.5 rounded-full bg-ink" /> : null}
                </span>
                <span className={i <= done ? 'text-ink' : 'text-muted'}>{p}</span>
              </li>
            ))}
          </ol>
          <p className="mt-4 text-[12px] leading-relaxed text-muted">
            Mock pipeline. In production: FFmpeg audio extraction, speech-to-text, diarisation, then Agnes 3.0 Flash for category, intent and importance.
          </p>
        </Card>

        <div className={cx('space-y-6 transition-opacity duration-500', ready ? 'opacity-100' : 'pointer-events-none opacity-30')} aria-busy={!ready}>
          {/* Category */}
          <Card className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[13px] text-muted">{category === video.detectedCategory ? 'Detected category' : 'Category, set by you'}</p>
                <p className="mt-0.5 text-[30px] font-bold leading-tight tracking-tight">{lens.label}</p>
                {category === video.detectedCategory && (
                  <p className="tnum mt-1 text-[13px] text-muted">
                    {Math.round(video.categoryConfidence * 100)}% confident. Next closest: {video.alternatives.map((a) => `${categoryById(a.id).label} ${Math.round(a.confidence * 100)}%`).join(', ')}
                  </p>
                )}
              </div>
              <Button size="sm" onClick={() => setChanging((c) => !c)} aria-expanded={changing}>
                {changing ? 'Done' : 'Change category'}
              </Button>
            </div>
            {changing && (
              <div className="step-in mt-4 flex flex-wrap gap-2">
                {CATEGORIES.map((c) => (
                  <Choice key={c.id} selected={c.id === category} onClick={() => dispatch({ type: 'set-category', category: c.id })}>
                    {c.label}
                  </Choice>
                ))}
              </div>
            )}
            <div className="mt-5 border-t border-line-2 pt-4">
              <p className="text-[13px] font-medium text-ink-2">The {lens.label.toLowerCase()} lens looks for</p>
              <ul className="mt-2 flex flex-wrap gap-1.5">
                {lens.looksFor.map((l) => (
                  <li key={l} className="rounded-md bg-line-2 px-2 py-1 text-[13px] text-ink-2">{l}</li>
                ))}
              </ul>
            </div>
          </Card>

          {/* Intent */}
          <Card className="p-5 sm:p-6">
            <label htmlFor="intent" className="text-[15px] font-semibold">What the creator is trying to say</label>
            <p className="mt-0.5 text-[13px] text-muted">Every cut is weighed against this. Edit it if it's not quite right.</p>
            <textarea
              id="intent"
              rows={2}
              value={state.intent}
              onChange={(e) => dispatch({ type: 'set-intent', intent: e.target.value })}
              className="mt-3 w-full resize-none rounded-lg border border-line bg-paper/50 px-3 py-2.5 font-serif text-[19px] italic leading-snug text-ink outline-none focus:border-ink-2"
            />
          </Card>

          <div className="grid gap-6 xl:grid-cols-2">
            {/* Important moments */}
            <Card className="p-5">
              <h2 className="text-[15px] font-semibold">Most important moments</h2>
              <p className="text-[13px] text-muted">Ranked by the {lens.label.toLowerCase()} lens. Change the category to see the ranking shift.</p>
              <ul className="mt-3 divide-y divide-line-2">
                {ranked.map(({ s, score }) => (
                  <li key={s.id} className="flex items-center gap-3 py-2.5">
                    <span className="tnum w-12 shrink-0 text-[13px] text-muted">{tc(s.start)}</span>
                    <span className="min-w-0 flex-1 truncate text-[14px]">{s.title}</span>
                    <span className="h-1.5 w-16 shrink-0 overflow-hidden rounded-full bg-line-2" aria-label={`Importance ${Math.round(score * 100)}%`}>
                      <span className="block h-full rounded-full bg-keep" style={{ width: `${score * 100}%` }} />
                    </span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Footage conditions */}
            <Card className="p-5">
              <h2 className="text-[15px] font-semibold">What's in the raw footage</h2>
              <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-3 text-[14px]">
                {[
                  ['Repetition', repeats.length, repeats.map((s) => `${tc(s.start)} repeats ${tc(video.segments.find((x) => x.id === s.repeats)!.start)}`)[0]],
                  ['Tangents', tangents.length, tangents[0] && `${tc(tangents[0].start)} ${tangents[0].title.replace(/^Tangent: /, '')}`],
                  ['Mistakes corrected', corrections.length, corrections[0] && `${tc(corrections[0].start)} corrects ${tc(video.segments.find((x) => x.id === corrections[0].corrects)!.start)}`],
                  ['Speakers', video.speakers.length, video.speakers.map((s) => s.name.split(' ').slice(-1)[0]).join(', ')],
                  ['Mixed-language parts', mixed.length, video.languages.map((l) => l.name).join(' and ')],
                  ['Noisy stretches', noisy.length, noisy[0] && `${tc(noisy[0].start)} ${noisy[0].title.toLowerCase()}`],
                  ['Long pauses', pauses.length, pauses[0] && `${tc(pauses[0].start)}, ${pauses[0].end - pauses[0].start}s`],
                ].map(([k, n, ex]) => (
                  <div key={k as string}>
                    <dt className="text-[13px] text-muted">{k}</dt>
                    <dd className="tnum font-semibold">
                      {n as number}
                      {ex ? <span className="ml-1.5 font-normal text-[12px] text-muted">{ex as string}</span> : null}
                    </dd>
                  </div>
                ))}
              </dl>
            </Card>
          </div>

          {/* Context links */}
          {links.length > 0 && (
            <Card className="p-5">
              <h2 className="text-[15px] font-semibold">Links ContextGuard will protect</h2>
              <p className="text-[13px] text-muted">If one side of a link is kept, the other side has to make sense without it, or come along.</p>
              <ul className="mt-3 grid gap-2 md:grid-cols-2">
                {links.map(({ from, to, kind }) => (
                  <li key={from.id + to.id} className="rounded-lg border border-line-2 bg-paper/40 p-3 text-[13px]">
                    <p className="font-medium text-guard">{kind}</p>
                    <p className="mt-1"><span className="tnum text-muted">{tc(from.start)}</span> {from.title} <span className="text-muted">({speakerName(video, from.speaker)})</span></p>
                    <p><span className="tnum text-muted">{tc(to.start)}</span> {to.title} <span className="text-muted">({speakerName(video, to.speaker)})</span></p>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
