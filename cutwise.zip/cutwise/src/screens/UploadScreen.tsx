import { useRef, useState } from 'react'
import { categoryById } from '../data/categories'
import { videos } from '../data'
import { human } from '../lib/format'
import { useStore } from '../state/store'
import { cx } from '../components/ui'
import type { Video } from '../types'

// One raw recording, three different edits. Each row keeps different parts.
const SOURCE = [3, 5, 2, 7, 4, 6, 3, 8, 2, 5, 4, 6, 3, 5]
const VERSIONS: { name: string; len: string; keep: number[]; guard: number[] }[] = [
  { name: 'Beginner lesson', len: '10:00', keep: [1, 3, 4, 5, 7, 9, 10, 12], guard: [7] },
  { name: 'Student revision', len: '5:00', keep: [3, 5, 7, 12], guard: [5] },
  { name: '60-second short', len: '1:00', keep: [5, 7], guard: [7] },
]

function SplitDiagram() {
  return (
    <figure className="rounded-2xl border border-line bg-card p-5 sm:p-6" aria-label="One recording becomes three different edits">
      <div className="mb-1.5 flex justify-between text-[12px] text-muted">
        <span>Raw lecture</span>
        <span className="tnum">28:40</span>
      </div>
      <div className="flex h-9 gap-[3px]">
        {SOURCE.map((w, i) => (
          <div key={i} style={{ flex: w }} className="rounded-[3px] bg-ink-2/80" />
        ))}
      </div>
      <div className="mt-5 space-y-4">
        {VERSIONS.map((v) => (
          <div key={v.name}>
            <div className="mb-1.5 flex justify-between text-[12px]">
              <span className="font-medium text-ink-2">{v.name}</span>
              <span className="tnum text-muted">{v.len}</span>
            </div>
            <div className="flex h-6 gap-[3px]">
              {SOURCE.map((w, i) => {
                const kept = v.keep.includes(i)
                const guard = v.guard.includes(i)
                return (
                  <div
                    key={i}
                    style={{ flex: w }}
                    className={cx('rounded-[3px]', guard ? 'bg-guard' : kept ? 'bg-keep' : 'hatch bg-cut-soft')}
                  />
                )
              })}
            </div>
          </div>
        ))}
      </div>
      <figcaption className="mt-5 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-muted">
        <span className="flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-keep" />Kept</span>
        <span className="flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-guard" />Protected</span>
        <span className="flex items-center gap-1.5"><i className="hatch size-2.5 rounded-sm bg-cut-soft" />Cut</span>
      </figcaption>
    </figure>
  )
}

export function UploadScreen() {
  const { dispatch } = useStore()
  const input = useRef<HTMLInputElement>(null)
  const [over, setOver] = useState(false)

  const load = (v: Video, name?: string) => dispatch({ type: 'load-video', video: v, uploadedName: name })
  const onFile = (f?: File | null) => f && load(videos[0], f.name)

  return (
    <div className="mx-auto max-w-[1180px] px-4 pb-20 pt-10 sm:px-6 lg:pt-16">
      <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-14">
        <div>
          <h1 className="max-w-[16ch] text-[40px] font-bold leading-[1.05] tracking-[-0.02em] sm:text-[52px]">
            Raw footage in. The right edit for every audience out.
          </h1>
          <p className="mt-5 max-w-[52ch] text-[17px] leading-relaxed text-ink-2">
            Cutwise works out what your video is, what you meant to say and who it is for. It plans the cuts itself, checks that no cut changes your meaning, and explains every decision.
          </p>

          <div
            onDragOver={(e) => { e.preventDefault(); setOver(true) }}
            onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); onFile(e.dataTransfer.files[0]) }}
            className={cx(
              'mt-8 flex flex-col items-start gap-3 rounded-xl border-2 border-dashed p-5 transition-colors sm:flex-row sm:items-center',
              over ? 'border-guard bg-guard-soft' : 'border-line bg-card/60',
            )}
          >
            <div className="flex-1">
              <p className="font-semibold">Drop a video file here</p>
              <p className="text-[13px] text-muted">MP4, MOV or MKV, up to 3 hours. This prototype runs the sample lecture analysis on any file.</p>
            </div>
            <input ref={input} type="file" accept="video/*" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
            <button onClick={() => input.current?.click()} className="h-10 rounded-lg bg-ink px-4 text-sm font-medium text-white hover:bg-ink-2">
              Choose file
            </button>
          </div>
        </div>
        <SplitDiagram />
      </div>

      <h2 className="mt-16 text-[15px] font-semibold">Or try a sample recording</h2>
      <div className="mt-3 grid gap-4 md:grid-cols-3">
        {videos.map((v) => (
          <button
            key={v.id}
            onClick={() => load(v)}
            className="group overflow-hidden rounded-xl border border-line bg-card text-left transition-colors hover:border-ink-2/40"
          >
            <div className="relative grid aspect-[16/7] place-items-center overflow-hidden" style={{ background: `linear-gradient(135deg, ${v.poster.from}, ${v.poster.to})` }}>
              <span className="font-serif text-[26px] italic text-white/85">{v.poster.glyph}</span>
              <span className="tnum absolute bottom-2 right-2 rounded bg-black/45 px-1.5 text-[12px] text-white">{human(v.duration)}</span>
            </div>
            <div className="p-4">
              <p className="font-semibold leading-snug">{v.title}</p>
              <p className="mt-1 text-[13px] text-muted">
                {categoryById(v.detectedCategory).label}, {v.speakers.length} speakers, {v.languages.map((l) => l.name).join(' and ')}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
