import { outputClips, spokenText } from '../../lib/edit'
import { tc } from '../../lib/format'
import type { Version, Video } from '../../types'
import { DecisionBadge } from '../ui'

/**
 * Mock preview. In production this plays the FFmpeg render; here it walks
 * the Edit Decision List and shows what the viewer would hear.
 */
export function Preview({ video, version, t, playing, onToggle, onSeek }: {
  video: Video
  version: Version
  t: number
  playing: boolean
  onToggle: () => void
  onSeek: (t: number) => void
}) {
  const clips = outputClips(video, version)
  const out = version.plan.outputSeconds
  const clip = clips.find((c) => t >= c.outStart && t < c.outEnd) ?? clips[clips.length - 1]
  const speaker = clip && video.speakers.find((s) => s.id === clip.seg.speaker)
  const srcTime = clip ? (clip.d.trimmedToCore && clip.seg.core ? clip.seg.core.start : clip.seg.start) + (t - clip.outStart) : 0

  return (
    <div className="overflow-hidden rounded-xl bg-ink">
      <div className="relative aspect-video w-full" style={{ background: `linear-gradient(135deg, ${video.poster.from}, ${video.poster.to})` }}>
        <span className="absolute inset-0 grid place-items-center font-serif text-[clamp(28px,6vw,64px)] italic text-white/10 select-none" aria-hidden>
          {video.poster.glyph}
        </span>
        <div className="absolute left-3 top-3 flex items-center gap-2">
          {clip && <DecisionBadge d={clip.d.decision} className="bg-white/90" />}
          <span className="tnum rounded bg-black/40 px-1.5 py-0.5 text-[12px] text-white/85">source {tc(srcTime)}</span>
        </div>
        {clip && (
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent px-5 pb-4 pt-12">
            <p className="text-[12px] font-medium text-white/70">{speaker?.name}{clip.seg.lang.length > 1 ? `, ${clip.seg.lang.join(' + ').toUpperCase()}` : ''}</p>
            <p className="mt-0.5 font-serif text-[clamp(16px,2.1vw,21px)] leading-snug text-white">{spokenText(clip.seg, clip.d)}</p>
          </div>
        )}
        {!clips.length && <p className="absolute inset-0 grid place-items-center text-white/70">Nothing kept in this version.</p>}
      </div>
      <div className="flex items-center gap-3 px-3 py-2.5 text-white">
        <button onClick={onToggle} aria-label={playing ? 'Pause preview' : 'Play preview'} className="grid size-8 place-items-center rounded-full bg-white text-ink">
          {playing ? (
            <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden><rect x="2" y="1" width="3" height="10" fill="currentColor" /><rect x="7" y="1" width="3" height="10" fill="currentColor" /></svg>
          ) : (
            <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden><path d="M3 1.5v9l7.5-4.5z" fill="currentColor" /></svg>
          )}
        </button>
        <input
          type="range"
          min={0}
          max={Math.max(1, out)}
          step={0.5}
          value={t}
          onChange={(e) => onSeek(Number(e.target.value))}
          aria-label="Seek in edited version"
          className="h-1 flex-1 cursor-pointer accent-white"
        />
        <span className="tnum text-[12px] text-white/80">{tc(t)} / {tc(out)}</span>
      </div>
    </div>
  )
}
